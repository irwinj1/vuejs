<template>
  <div>
    <v-toolbar>
      <v-toolbar-title>Formularios</v-toolbar-title>

      <v-spacer></v-spacer>
    </v-toolbar>
  </div>
</template>
<script>
export default {
  data() {
    return {
      appTitle: "Formularios",
      sidebar: false,
    };
  },
};
</script>